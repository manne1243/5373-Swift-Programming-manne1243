//
//  AboutViewController.swift
//  BullsEye
//
//  Created by akhilesh kalaru on 2/14/15.
//  Copyright (c) 2015 akhilesh kalaru. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    @IBAction func close(){
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
